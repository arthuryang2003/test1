WANDB_MODE=disabled python train_ssa.py --e test
